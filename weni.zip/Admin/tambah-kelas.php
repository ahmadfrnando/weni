<h5>Halaman Tambah Data Kelas</h5>
<a href="?url=kelas" class="btn btn-primary btn-sm">Kembali</a>
<hr>
<form method="post" action="?url=proses-tambah-kelas">
    <div class="form-group mb-2">
        <label>Nama Kelas</label>
        <input type="text" name="nama_kelas" class="form-control" required>
    </div>
    <div class="form-group mb-2">
        <label>Kompetensi Keahlian</label>
        <input type="text" name="kompetensi_keahlian" class="form-control" required>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-success btn-sm">Simpan</button>
        <button type="reset" class="btn btn-warning btn-sm">Kosongkan</button>
    </div>
</form>