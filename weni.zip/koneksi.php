<?php
$koneksi = mysqli_connect('127.0.0.1','root','root','weni');

if(!$koneksi){
    echo"Koneksi Anda Gagal";
}

?>
